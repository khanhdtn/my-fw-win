using System;
using System.Resources;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using CustomControls.HelperClasses;

namespace CustomControls.BaseClasses
{
	
	public sealed class ImageRes
	{

		
		private static ImageList _ImageList=null;
		private static ResourceManager _RM= null;

		public static ResourceManager RM
		{
			get
			{
				if(_RM==null)
				{
					_RM= new ResourceManager("CustomControls.ImageRes",System.Reflection.Assembly.GetExecutingAssembly());
				}
				return _RM;
			}
		}


		public static ImageList ImageList
		{
			get
			{
				if(_ImageList==null)
				{
					_ImageList= new ImageList();
					_ImageList.ImageStream=((ImageListStreamer)RM.GetObject("ImageStream"));
				}
				return _ImageList;
			}
		}


		public ImageRes()
		{
	
		}

		public static Image GetImage(string ImageName)
		{
			return (Image)RM.GetObject(ImageName);
			
		}
	}


}


namespace CustomControls.HelperClasses
{
	public class NameObject
	{
		private string _Name=string.Empty;
		private object _Object=null;

		public string Name
		{
			get{return _Name;}
			set{_Name=value;}
		}

		public object Object
		{
			get{return _Object;}
			set{_Object= value;}
		}

		public NameObject()
		{}

		public NameObject(string Name, object Object)
		{
			_Name= Name;
			_Object=Object;
		}
	}

	public class NameObjectCollection:CollectionBase
	{

		private NameObject_Comparer noc=null;

		public NameObject_Comparer NOC
		{
			get
			{
				if(noc==null)
				{
					noc= new NameObject_Comparer();
				}
				return noc;
			}
		}

		public int Add(NameObject no)
		{
			return this.InnerList.Add(no);
		}

		public int Add(string Name, object Object)
		{
			return this.Add(new NameObject(Name, Object));
		}

		public void Remove(NameObject no)
		{
			this.InnerList.Remove(no);
		}

		public int IndexOf(NameObject no)
		{
			return this.InnerList.IndexOf(no);
		}

		public int IndexOf(string Name)
		{
			return Search(Name);
		}

		public new void RemoveAt(int Index)
		{
			 this.RemoveAt(Index);
		}

		public void Sort()
		{
			this.InnerList.Sort(NOC);
		}

		public int Search(string Name)
		{
			Sort();
			return this.InnerList.BinarySearch(Name, NOC);
		}

		public NameObject this[int Index]
		{
			get{return (NameObject)this.InnerList[Index];}
			set{this.InnerList[Index]= value;}
		}

		public NameObject this[string Name]
		{
			get
			{
				int index= this.Search(Name);
				if(index>-1){return (NameObject)this[index];}
				else{return null;}
			}
			set
			{
				int index= this.Search(Name);
				if(index>-1){ this[index]= value;}
				
			}
		}
	}

	public class NameObject_Comparer:System.Collections.IComparer
	{
		int System.Collections.IComparer.Compare (object o1, object o2)
		{
			string Name1,Name2;
 
			NameObject nameObject1= o1 as NameObject;
			NameObject nameObject2= o2 as NameObject;

			if(nameObject1==null){Name1=o1.ToString();}
			else{Name1=nameObject1.Name;}

			if(nameObject2==null){Name2=o2.ToString();}
			else{Name2=nameObject2.Name;}

			return string.Compare(Name1, Name2);
		}
	}
}