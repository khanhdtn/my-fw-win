using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using System.Globalization;
using System.ComponentModel.Design.Serialization;
using CustomControls.HelperClasses;
using CustomControls.BaseClasses;
using CustomControls.Editors;
using CustomControls.Functions;
using CustomControls.ApplicationBlocks;

namespace CustomControls.BaseClasses
{
	public abstract class PrintCommand:DynamicTypeDescriptor 
	{
		public abstract int  GetHeight(Graphics g,PrintEngine pe,int maxWidth );
		public abstract int  Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth);
		
		public override string GetLocalizedName(string Name)
		{			
			string name=CustomControls.Globalization.Dictionary.Translate(Name);
			if(name!=null ){return name;}
			return base.GetLocalizedName (Name);
		}

		public override string GetLocalizedDescription(string Description)
		{
			string descr=CustomControls.Globalization.Dictionary.Translate(Description + "_Descr");
			if(descr!=null ){return descr;}
			return base.GetLocalizedName (Description);
		}

		[Browsable(false)]
		public override PropertyCommands PropertyCommands
		{
			get
			{
				return base.PropertyCommands;
			}
		}

		[Browsable(false)]
		public override CategoryCommands CategoryCommands
		{
			get
			{
				return base.CategoryCommands;
			}
		}


	}


	public class PrintElement:PrintCommands
	{
		
		PrintEngine pe;
		
		public PrintElement(PrintEngine pe)
		{
			this.pe=pe;
		}

		public int GetHeight(Graphics g, int maxWidth)
		{
			int height=0;

			foreach(PrintCommand pc in this )
			{
				height+=pc.GetHeight(g,pe,maxWidth);
			}
		
			return height;
		}

		public int GetHeight(Graphics g, int maxWidth, int maxHeight)
		{
			int height=0;

			foreach(PrintCommand pc in this )
			{
				if (height>maxHeight) return maxHeight;
				height+=pc.GetHeight(g,pe,maxWidth);
			}
		
			return height;
		}
		
		public int Draw(Graphics g,Point startPoint, int maxWidth)
		{
			int yOffset=startPoint.Y;

			foreach(PrintCommand pc in this )
			{
				yOffset+=pc.Draw(g,pe,new Point(startPoint.X,startPoint.Y+yOffset),maxWidth);
			}
			return yOffset;
		}

		public Bitmap GetElementBitmap(int maxWidth, int maxHeight)
		{
			Bitmap bmp=new Bitmap(maxWidth, maxHeight);
			int yOffset=0;
		
			using (Graphics g=Graphics.FromImage(bmp))
			{
				foreach(PrintCommand pc in this )
				{
					if(yOffset>=maxHeight){return FadeCut(g, bmp);}
					yOffset+=pc.Draw(g,pe,new Point(0,yOffset),maxWidth);
				}
			
				if(yOffset>0 && maxWidth>0 )
				{
					if(yOffset>=maxHeight){return FadeCut(g, bmp);}
					else
					{
						Bitmap	cloneBmp=bmp.Clone(new Rectangle(0,0,maxWidth,yOffset),bmp.PixelFormat);
						bmp.Dispose();
						bmp=null;
						return cloneBmp;
					}
				}
				else 
				{
					bmp.Dispose();
					bmp=null;
					return new Bitmap(maxWidth,1);
				}
			}
		}


		private Bitmap FadeCut(Graphics g, Bitmap bmp)
		{
			if(bmp.Height>20 && bmp.Width>40)
			{
				Rectangle gradRect= new Rectangle(0,bmp.Height-20,bmp.Width,10);
				Rectangle whiteRect= new Rectangle(0,bmp.Height-10,bmp.Width,10);
				using (LinearGradientBrush  gradBrush= new LinearGradientBrush(gradRect,Color.Transparent,Color.White,LinearGradientMode.Vertical))
				{
					g.FillRectangle(gradBrush,gradRect);
					g.FillRectangle(Brushes.White,whiteRect);
				}
				
				using (Pen cutPen=new Pen(Color.Red,1))
				{
					cutPen.DashStyle=DashStyle.Dash;
					g.DrawLine(cutPen,0,bmp.Height-10,bmp.Width,bmp.Height-10);
				}
				Bitmap scissors= (Bitmap)CustomControls.BaseClasses.ImageRes.GetImage("RedScissors");
				g.DrawImage(scissors,28,bmp.Height-17,16,16);
				scissors=null;
			}
			return bmp;
		}

	}


	public class PrintCommands:CollectionBase
	{
		public int Add(PrintCommand pc)
		{
			return this.InnerList.Add(pc);
		}

		public void AddRange(PrintCommand[] pcs)
		{
			this.InnerList.AddRange(pcs);
		}

		public void Remove(PrintCommand pc)
		{
			this.InnerList.Remove(pc);
		}

		public new void RemoveAt(int index)
		{
			this.InnerList.RemoveAt(index);
		}

		public PrintCommand this[int index]
		{
			get{return (PrintCommand)this.InnerList[index];}
			set{this.InnerList[index]= value;}
		}

		
		
	}


	[TypeConverter(typeof(HRule_Converter))]
	public class HRuleCommand:PrintCommand
	{
		private int _Width=1;
		private Color _Color= Color.Black;
		private DashStyle _DashStyle=DashStyle.Solid;

		public int Width
		{
			get{return _Width;}
			set{_Width= value;}
		}

		public Color Color
		{
			get{return _Color;}
			set{_Color= value;}
		}

		public DashStyle DashStyle
		{
			get{return _DashStyle;}
			set{_DashStyle= value;}
		}


		public HRuleCommand()
		{
			
		}

		public HRuleCommand(int width, Color color, DashStyle dashStyle)
		{
			this._Width=width;
			this._Color= color;
			this._DashStyle= dashStyle;
		}

		public  override int GetHeight(Graphics g,PrintEngine pe, int maxWidth)
		{
			return Width;
		}

		public override int Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth)
		{
			int yOffset=Width/2;
			using(Pen pen= new Pen(Color,Width))
			{
				pen.DashStyle=DashStyle;
				g.DrawLine(pen,new Point(startPoint.X ,startPoint.Y + yOffset),new Point(startPoint.X + maxWidth,startPoint.Y+ yOffset));
			}
			return Width;
		}
		

	}

	[TypeConverter(typeof(ColumnsHeader_Converter))]
	public class ColumnsHeaderCommand:PrintCommand
	{
		private Color _BackColor=Color.SlateGray;
		private Color _ForeColor=Color.GhostWhite;
		private Color _LineColor=Color.Navy;
		private Font _Font=new System.Drawing.Font("Tahoma", 10.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		private DataGridLineStyle _LineStyle=DataGridLineStyle.Solid;
		private int _Height=20;


		[Category("Header")]
		public Color BackColor
		{
			get{return _BackColor;}
			set
			{
				if(value!=_BackColor)
				{
					_BackColor=value;
					
				}
			}
		}

		[Category("Header")]
		public Color ForeColor
		{
			get{return _ForeColor;}
			set
			{
				if(value!=_ForeColor)
				{
					_ForeColor=value;
					
				}
			}
		}

		
		[Category("Header")]
		public Color LineColor
		{
			get{return _LineColor;}
			set
			{
				if(value!=_LineColor)
				{
					_LineColor=value;
					
				}
			}
		}

		[Category("Header")]
		public Font Font
		{
			get{return _Font;}
			set
			{
				if(value!=_Font)
				{
					_Font=value;
					
				}
			}
		}


		[Category("Header")]
		public DataGridLineStyle LineStyle
		{
			get{return _LineStyle;}
			set
			{
				if(value !=_LineStyle)			
				{
					_LineStyle= value;
					
				}
			}
		}

		[Category("Header")]
		[DefaultValue(typeof(int),"20")]
		public int Height
		{
			get{return _Height;}
			set
			{
				if(value !=_Height)
				{
					_Height= value;
					
				}
			}
		}


		public ColumnsHeaderCommand()
		{}

		public ColumnsHeaderCommand(Color BackColor, Color ForeColor,Color LineColor,Font Font,int Height,DataGridLineStyle LineStyle )
		{
			this._BackColor= BackColor;
			this._ForeColor=ForeColor;
			this._LineColor=LineColor;
			this._Font=Font;
			this._Height=Height;
			this._LineStyle=LineStyle;
		}

		public override int GetHeight(Graphics g,PrintEngine pe, int maxWidth)
		{
			return Height;
		}

		public override int Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth)
		{
		
			if(pe!=null && pe.CurrentPage!=null)
			{
				Rectangle VirtualRegion= new Rectangle(pe.CurrentPage.ClientRectangle.Left,0,pe.CurrentPage.ClientRectangle.Width, Height);
				Bitmap CHBitmap= pe.Client.GetColumnsHeaderBitmap(VirtualRegion,BackColor, ForeColor, LineColor,Font,Height,LineStyle);
				g.DrawImage(CHBitmap,startPoint.X,startPoint.Y,VirtualRegion.Width,Height);
			}
			else
			{
				Rectangle rect= new Rectangle(startPoint.X,startPoint.Y,maxWidth,Height);
				using (SolidBrush brush= new SolidBrush(BackColor))
				{
					g.FillRectangle(brush,rect);
					brush.Color=ForeColor;
					StringFormat strFormat= new StringFormat();
					strFormat.Alignment=StringAlignment.Center;
					strFormat.LineAlignment=StringAlignment.Center;
					g.DrawString("Columns Header",Font,brush,rect,strFormat);
				}
				if(LineStyle==DataGridLineStyle.Solid)
				{
					using(Pen pen= new Pen(LineColor))
					{
						g.DrawRectangle(pen,startPoint.X, startPoint.Y, maxWidth-1,Height-1 );
					}
				}
			}
			return Height;
		}
		
	}

	[TypeConverter(typeof(BlankLine_Converter))]
	public class BlankLineCommand:PrintCommand
	{
		private int _Height=10;

		public int Height
		{
			get{return _Height;}
			set{_Height= value;}
		}

		public BlankLineCommand()
		{}

		public BlankLineCommand(int height)
		{
			this._Height= height;
		}

		public override int GetHeight(Graphics g,PrintEngine pe, int maxWidth)
		{
			return Height;
		}

		public override int Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth)
		{
			return Height;
		}
		
	}


	[TypeConverter(typeof(Text_Converter))]
	public class TextCommand:PrintCommand
	{
		private string _Text= string.Empty;
		private Font _Font=new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		private Color _ForeColor= Color.Black;
		private Color _BackColor=Color.White;
		private HorizontalAlignment _Alignment=HorizontalAlignment.Left;
		protected StringFormat strFormat=new StringFormat();


		public string Text
		{
			get{return _Text;}
			set{_Text= value;}
		}

		public  Font Font
		{
			get{return _Font;}
			set{_Font= value;}
		}

		public Color ForeColor
		{
			get{return _ForeColor;}
			set{_ForeColor= value;}
		}

		public Color BackColor
		{
			get{return _BackColor;}
			set{_BackColor= value;}
		}

		public HorizontalAlignment Alignment
		{
			get{return _Alignment;}
			set
			{
				if(value!=_Alignment)
				{
					_Alignment= value;
					strFormat.Alignment=General.HorAlignToStrAlign(value);
				}
			}
		}

		public TextCommand()
		{			
			strFormat.LineAlignment=StringAlignment.Center;
			strFormat.Trimming=StringTrimming.None;
		}

		public TextCommand(string text, Font font,Color backColor, Color foreColor, HorizontalAlignment alignment):this()
		{
			this._Text= text;
			this._Font= font;
			this._BackColor=backColor;
			this.ForeColor= foreColor;
			this._Alignment=alignment;
			strFormat.Alignment=General.HorAlignToStrAlign(Alignment);
		}

		


		public override int GetHeight(Graphics g,PrintEngine pe, int maxWidth)
		{
			return (int)g.MeasureString(Text,Font,maxWidth,strFormat).Height +1;
		}

		public override int Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth)
		{
			SizeF textSize=g.MeasureString(Text,Font,maxWidth,strFormat);

			RectangleF textRect= new RectangleF(startPoint.X, startPoint.Y,maxWidth, (int)textSize.Height+1);
			
			string pText=Text;


			if(pe!=null && pe.PagEngine!=null )
			{
				if(pe.CurrentPage!=null	)
				{
					int currPage=pe.PagEngine.Pages.IndexOf(pe.CurrentPage)+1;
					pText=pText.Replace("[PgNum]",currPage.ToString());

					pText=pText.Replace("[PgNumArr]",(pe.CurrentPage.Row +1).ToString() +":" + (pe.CurrentPage.Column+1).ToString());
					pText=pText.Replace("[PgCol]", (pe.CurrentPage.Column+1).ToString());
					pText=pText.Replace("[PgRow]", (pe.CurrentPage.Row+1).ToString());
				}
			
				pText=pText.Replace("[TotalPgs]", pe.PagEngine.Pages.Count.ToString());
			}
			


			using (SolidBrush brush= new SolidBrush(BackColor))
			{
				g.FillRectangle(brush,textRect);
				brush.Color=ForeColor;
				g.DrawString(pText,Font,brush,textRect,strFormat);
			}

			return (int)textSize.Height +1;
		}

		

	}


	[TypeConverter(typeof(Date_Converter))]
 	public class DateCommand:PrintCommand
	{
		private DateTime _Date= DateTime.Today;
		private Font _Font=new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		private Color _Color= Color.Black;
		private HorizontalAlignment _Alignment=HorizontalAlignment.Left;
		protected StringFormat strFormat=new StringFormat();
		private string _Format="d";



		public string Format
		{
			get{return _Format;}
			set{_Format= value;}
		}

		public DateTime Date
		{
			get{return _Date;}
			set{_Date= value;}
		}

		public  Font Font
		{
			get{return _Font;}
			set{_Font= value;}
		}

		public Color Color
		{
			get{return _Color;}
			set{_Color= value;}
		}

		private string FDate
		{
			get{return Date.ToString(Format,System.Globalization.CultureInfo.CurrentUICulture);}
		}

		public HorizontalAlignment Alignment
		{
			get{return _Alignment;}
			set
			{
				if(value!=_Alignment)
				{
					_Alignment= value;
					strFormat.Alignment=General.HorAlignToStrAlign(value);
				}
			}
		}

		public DateCommand()
		{
			
			strFormat.LineAlignment=StringAlignment.Center;
			strFormat.Trimming=StringTrimming.None;
		}
		// we use this constructor for serialization 
		//since is more convenient that the Date property  have always the DateTime.Today value
		//and we shouldn't serialize its value
		public DateCommand	(string format , Font font, Color color, HorizontalAlignment alignment):this()
		{
			this._Format= format;
			this._Font= font;
			this._Color= color;
			this._Alignment=alignment;
			strFormat.Alignment=General.HorAlignToStrAlign(Alignment);
		}
		public DateCommand	(DateTime date,string format , Font font, Color color, HorizontalAlignment alignment):this()
		{
			this._Date= date;
			this._Format= format;
			this._Font= font;
			this._Color= color;
			this._Alignment=alignment;
			strFormat.Alignment=General.HorAlignToStrAlign(Alignment);
		}

	public override int GetHeight(Graphics g,PrintEngine pe, int maxWidth)
	{
		return (int)g.MeasureString(FDate,Font,maxWidth,strFormat).Height +1;
	}

	public override int Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth)
	{
		SizeF textSize=g.MeasureString(FDate,Font,maxWidth,strFormat);

		RectangleF textRect= new RectangleF(startPoint.X, startPoint.Y,maxWidth, (int)textSize.Height+1);
			
		using (SolidBrush brush= new SolidBrush(Color))
		{
			g.DrawString(FDate,Font,brush,textRect,strFormat);
		}

		return (int)textSize.Height +1;
	}

		public override string ToString()
		{
			return "Date";
		}
	}

	[TypeConverter(typeof(Picture_Converter))]
	public class PictureCommand: PrintCommand
	{
		private HorizontalAlignment _Alignment=HorizontalAlignment.Left;
		private Image _Picture= null; 


		public HorizontalAlignment Alignment
		{
			get{return _Alignment;}
			set
			{
				if(value!=_Alignment)
				{
					_Alignment= value;
				}
			}
		}

		public Image Picture
		{
			get{return _Picture;}
			set{_Picture= value;}
		}


		public PictureCommand()
		{}

		public PictureCommand(Image picture, HorizontalAlignment alignment)
		{
			this._Picture= picture;
			this._Alignment= alignment;
		}

		public override int GetHeight(Graphics g,PrintEngine pe, int maxWidth)
		{
			if(this.Picture!=null){return Math.Min(maxWidth,Picture.Height );}
			else{return 0;}
		}

		public override int Draw(Graphics g,PrintEngine pe,Point startPoint, int maxWidth)
		{
			if(Picture!=null )
			{	
				int x=startPoint.X+ GetPicHPosition(Alignment,Picture.Width,maxWidth);
				int y=startPoint.Y;
				
			
				Rectangle imgRect=new Rectangle( x,y,Picture.Width,Picture.Height);
				g.DrawImage(Picture,imgRect);
						

				return Picture.Height;
			}
			else{return 0;}
		}


		public int GetPicHPosition(HorizontalAlignment alignment,int picWidth,int maxWidth)
		{
			switch(alignment)
			{
				case HorizontalAlignment.Left:
				{
					return 0;
				}
				case HorizontalAlignment.Center:
				{
					return (maxWidth-picWidth)/2;
				}
				case HorizontalAlignment.Right:
				{
					return maxWidth-picWidth;
				}
				default:
				{
					return 0;
				}

			}
		}

	
		
	}
}

namespace CustomControls.HelperClasses
{

	internal class ColumnsHeader_Converter:ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(ColumnsHeaderCommand).GetConstructor(new Type[]{typeof(Color),typeof(Color), typeof(Color), typeof(Font),typeof(int), typeof(DataGridLineStyle)}), new object[] {((ColumnsHeaderCommand)value).BackColor,((ColumnsHeaderCommand)value).ForeColor,((ColumnsHeaderCommand)value).LineColor,((ColumnsHeaderCommand)value).Font,((ColumnsHeaderCommand)value).Height,((ColumnsHeaderCommand)value).LineStyle},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}
		
		
	}


	internal class HRule_Converter:ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(HRuleCommand).GetConstructor(new Type[]{typeof(int), typeof(Color), typeof(DashStyle)}), new object[] {((HRuleCommand)value).Width,((HRuleCommand)value).Color,((HRuleCommand)value).DashStyle},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}
	}

	internal class BlankLine_Converter:ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(BlankLineCommand).GetConstructor(new Type[]{typeof(int)}), new object[] {((BlankLineCommand)value).Height},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}
	}

	internal class Text_Converter:ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		

		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(TextCommand).GetConstructor(new Type[]{typeof(string),typeof(Font),typeof(Color),typeof(Color), typeof(HorizontalAlignment)}), new object[] {((TextCommand)value).Text,((TextCommand)value).Font,((TextCommand)value).BackColor,((TextCommand)value).ForeColor, ((TextCommand)value).Alignment},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}
	}

	internal class Date_Converter:ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		

		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(DateCommand).GetConstructor(new Type[]{typeof(string),typeof(Font),typeof(Color), typeof(HorizontalAlignment)}), new object[] {((DateCommand)value).Format ,((DateCommand)value).Font,((DateCommand)value).Color, ((DateCommand)value).Alignment},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}
	}

	internal class Picture_Converter:ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		

		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(PictureCommand).GetConstructor(new Type[]{typeof(Image), typeof(HorizontalAlignment)}), new object[] {((PictureCommand)value).Picture, ((PictureCommand)value).Alignment},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}
	}

	internal class PrintElementCollEditForm:CustomControls.Editors.HFCollectionEditor
	{

		public PrintElementCollEditForm()
		{
			this.ImageList=CustomControls.BaseClasses.ImageRes.ImageList;
		}

		
	
		protected override Type[] CreateNewItemTypes(IList coll)
		{
			return new Type[]{typeof(HRuleCommand),typeof(BlankLineCommand),typeof(TextCommand),typeof(DateCommand),typeof(PictureCommand), typeof(ColumnsHeaderCommand)};
		}
	
		
	
		protected override void SetProperties(TItem titem, object reffObject)
		{
			base.SetProperties (titem, reffObject);


			if(reffObject is HRuleCommand )
			{
				titem.Text="Horizontal Rule";
				titem.ForeColor=Color.Gray;
				titem.ImageIndex=2;
				titem.SelectedImageIndex=2;
			}
			else if(reffObject is BlankLineCommand )
			{
				titem.Text="Blank Line";
				titem.ForeColor=Color.Tan;
				titem.ImageIndex=3;
				titem.SelectedImageIndex=3;

			}
			else if(reffObject is TextCommand )
			{
				titem.Text="Text";
				titem.ForeColor=Color.Navy;
				titem.ImageIndex=4;
				titem.SelectedImageIndex=4;
			}
			else if(reffObject is DateCommand )
			{
				titem.Text="Date";
				titem.ForeColor=Color.DarkGreen;
				titem.ImageIndex=5;
				titem.SelectedImageIndex=5;
			}
			else if(reffObject is PictureCommand )
			{
				titem.Text="Picture";
				titem.ForeColor=Color.Maroon;
				titem.ImageIndex=6;
				titem.SelectedImageIndex=6;
			}
			else if(reffObject is ColumnsHeaderCommand )
			{
				titem.Text="Columns Header";
				titem.ForeColor=Color.Blue;
				titem.ImageIndex=1;
				titem.SelectedImageIndex=1;
			}
		}
	}

	internal class PrintElementCollEdit:CustomCollectionEditor
	{
		protected override CustomCollectionEditorForm CreateForm()
		{
			return new PrintElementCollEditForm ();
		}

	}
}