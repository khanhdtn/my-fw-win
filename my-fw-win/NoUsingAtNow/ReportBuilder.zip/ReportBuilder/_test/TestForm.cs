using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ProjectLibrary.Controls;

using ProjectLibrary.General;

namespace ReportBuilder
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class TestForm : PForm
	{
		private CustomControls.ApplicationBlocks.ReportBuilder repBuilder;
		private ds_Orders ds_Orders1;
		private System.Windows.Forms.ImageList img_Icons;
		private System.Windows.Forms.ToolBarButton toolBarButton1;
		private System.Windows.Forms.ToolBarButton toolBarButton2;
		private System.Windows.Forms.ToolBarButton toolBarButton3;
		private System.Windows.Forms.ToolBarButton toolBarButton4;
		private System.Windows.Forms.ToolBarButton tbtn_Print;
		private ProjectLibrary.Controls.PToolBar tb_Main;
	
		private PButton btn_PrintGrid;
		
		private PDataGrid dg_Orders;
		private System.Windows.Forms.GroupBox gb_Custom;
		private System.Windows.Forms.GroupBox gb_Standard;
		private PComboBox cb_OrderrID;
		private PListBox lb_CustomerID;
		private System.Windows.Forms.ComboBox cb_ShipName;
		private System.Windows.Forms.ListBox lb_ShipCity;
		private System.Windows.Forms.DataGridTableStyle dataGridTableStyle1;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn2;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn3;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn4;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn5;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn6;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn7;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn8;
		private System.ComponentModel.IContainer components;

		public TestForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			this.dataGridTextBoxColumn1.Width = 100;
			this.dataGridTextBoxColumn2.Width = 120;
			this.dataGridTextBoxColumn3.Width = 120;
			this.dataGridTextBoxColumn4.Width = 140;
			this.dataGridTextBoxColumn5.Width = 200;
			this.dataGridTextBoxColumn6.Width = 200;
			this.dataGridTextBoxColumn7.Width = 120;
			this.dataGridTextBoxColumn8.Width = 120;
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TestForm));
			CustomControls.ApplicationBlocks.TableStyle tableStyle1 = new CustomControls.ApplicationBlocks.TableStyle();
			CustomControls.ApplicationBlocks.ColumnStyle columnStyle1 = new CustomControls.ApplicationBlocks.ColumnStyle();
			CustomControls.ApplicationBlocks.ColumnStyle columnStyle2 = new CustomControls.ApplicationBlocks.ColumnStyle();
			CustomControls.ApplicationBlocks.ColumnStyle columnStyle3 = new CustomControls.ApplicationBlocks.ColumnStyle();
			CustomControls.ApplicationBlocks.ColumnStyle columnStyle4 = new CustomControls.ApplicationBlocks.ColumnStyle();
			CustomControls.ApplicationBlocks.ColumnStyle columnStyle5 = new CustomControls.ApplicationBlocks.ColumnStyle();
			this.ds_Orders1 = new ReportBuilder.ds_Orders();
			this.repBuilder = new CustomControls.ApplicationBlocks.ReportBuilder();
			this.dg_Orders = new ProjectLibrary.Controls.PDataGrid();
			this.dataGridTableStyle1 = new System.Windows.Forms.DataGridTableStyle();
			this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn2 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn3 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn4 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn5 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn6 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn7 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn8 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.lb_ShipCity = new System.Windows.Forms.ListBox();
			this.cb_OrderrID = new ProjectLibrary.Controls.PComboBox();
			this.tb_Main = new ProjectLibrary.Controls.PToolBar();
			this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton2 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton3 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton4 = new System.Windows.Forms.ToolBarButton();
			this.tbtn_Print = new System.Windows.Forms.ToolBarButton();
			this.img_Icons = new System.Windows.Forms.ImageList(this.components);
			this.btn_PrintGrid = new ProjectLibrary.Controls.PButton();
			this.lb_CustomerID = new ProjectLibrary.Controls.PListBox();
			this.gb_Custom = new System.Windows.Forms.GroupBox();
			this.gb_Standard = new System.Windows.Forms.GroupBox();
			this.cb_ShipName = new System.Windows.Forms.ComboBox();
			((System.ComponentModel.ISupportInitialize)(this.ds_Orders1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repBuilder)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dg_Orders)).BeginInit();
			this.gb_Custom.SuspendLayout();
			this.gb_Standard.SuspendLayout();
			this.SuspendLayout();
			// 
			// ds_Orders1
			// 
			this.ds_Orders1.DataSetName = "ds_Orders";
			this.ds_Orders1.Locale = new System.Globalization.CultureInfo("en-US");
			// 
			// repBuilder
			// 
			this.repBuilder.DataSource = this.dg_Orders;
			this.repBuilder.PageFooter.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																								  new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Black, System.Drawing.Drawing2D.DashStyle.Solid),
																								  new CustomControls.BaseClasses.BlankLineCommand(4),
																								  new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Black, System.Drawing.Drawing2D.DashStyle.Solid),
																								  new CustomControls.BaseClasses.TextCommand("Page [PgNum]", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.Black, System.Windows.Forms.HorizontalAlignment.Center)});
			this.repBuilder.PageHeader.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																								  new CustomControls.BaseClasses.ColumnsHeaderCommand(System.Drawing.Color.SlateGray, System.Drawing.Color.GhostWhite, System.Drawing.Color.Navy, new System.Drawing.Font("Tahoma", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), 20, System.Windows.Forms.DataGridLineStyle.Solid)});
			this.repBuilder.ReportFooter.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																									new CustomControls.BaseClasses.DateCommand("D", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.Black, System.Windows.Forms.HorizontalAlignment.Right)});
			this.repBuilder.ReportHeader.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																									new CustomControls.BaseClasses.PictureCommand(((System.Drawing.Bitmap)(resources.GetObject("resource"))), System.Windows.Forms.HorizontalAlignment.Right),
																									new CustomControls.BaseClasses.TextCommand("Orders", new System.Drawing.Font("Tahoma", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.SlateGray, System.Windows.Forms.HorizontalAlignment.Center),
																									new CustomControls.BaseClasses.BlankLineCommand(20)});
			tableStyle1.AlternatingBackColor = System.Drawing.Color.Gainsboro;
			tableStyle1.BackColor = System.Drawing.Color.White;
			tableStyle1.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										 new CustomControls.HelperClasses.CategoryCommand("Column Styles", true),
																										 new CustomControls.HelperClasses.CategoryCommand("Grid", true)});
			columnStyle1.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
			columnStyle1.BackColor = System.Drawing.Color.Wheat;
			columnStyle1.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										  new CustomControls.HelperClasses.CategoryCommand("Misc", true)});
			columnStyle1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			columnStyle1.ForeColor = System.Drawing.Color.Black;
			columnStyle1.Format = "";
			columnStyle1.HeaderText = "OrderID";
			columnStyle1.MappingName = "OrderID";
			columnStyle1.NullText = "Null";
			columnStyle1.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										  new CustomControls.HelperClasses.PropertyCommand("Alignment", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("BackColor", true, true),
																										  new CustomControls.HelperClasses.PropertyCommand("Font", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("ForeColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Format", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("HeaderText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("MappingName", false, false),
																										  new CustomControls.HelperClasses.PropertyCommand("NullText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Visible", false, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Width", true, true)});
			columnStyle1.Visible = true;
			columnStyle1.Width = 80;
			columnStyle2.Alignment = System.Windows.Forms.HorizontalAlignment.Left;
			columnStyle2.BackColor = System.Drawing.Color.Transparent;
			columnStyle2.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										  new CustomControls.HelperClasses.CategoryCommand("Misc", true)});
			columnStyle2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			columnStyle2.ForeColor = System.Drawing.Color.Black;
			columnStyle2.Format = "";
			columnStyle2.HeaderText = "CustomerID";
			columnStyle2.MappingName = "CustomerID";
			columnStyle2.NullText = "Null";
			columnStyle2.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										  new CustomControls.HelperClasses.PropertyCommand("Alignment", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("BackColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Font", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("ForeColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Format", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("HeaderText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("MappingName", false, false),
																										  new CustomControls.HelperClasses.PropertyCommand("NullText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Visible", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Width", true, true)});
			columnStyle2.Visible = true;
			columnStyle2.Width = 100;
			columnStyle3.Alignment = System.Windows.Forms.HorizontalAlignment.Left;
			columnStyle3.BackColor = System.Drawing.Color.Transparent;
			columnStyle3.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										  new CustomControls.HelperClasses.CategoryCommand("Misc", true)});
			columnStyle3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			columnStyle3.ForeColor = System.Drawing.Color.Black;
			columnStyle3.Format = "d";
			columnStyle3.HeaderText = "RequiredDate";
			columnStyle3.MappingName = "RequiredDate";
			columnStyle3.NullText = "Null";
			columnStyle3.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										  new CustomControls.HelperClasses.PropertyCommand("Alignment", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("BackColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Font", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("ForeColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Format", true, true),
																										  new CustomControls.HelperClasses.PropertyCommand("HeaderText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("MappingName", false, false),
																										  new CustomControls.HelperClasses.PropertyCommand("NullText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Visible", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Width", true, false)});
			columnStyle3.Visible = true;
			columnStyle3.Width = 120;
			columnStyle4.Alignment = System.Windows.Forms.HorizontalAlignment.Left;
			columnStyle4.BackColor = System.Drawing.Color.Transparent;
			columnStyle4.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										  new CustomControls.HelperClasses.CategoryCommand("Misc", true)});
			columnStyle4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			columnStyle4.ForeColor = System.Drawing.Color.Black;
			columnStyle4.Format = "";
			columnStyle4.HeaderText = "ShipName";
			columnStyle4.MappingName = "ShipName";
			columnStyle4.NullText = "Null";
			columnStyle4.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										  new CustomControls.HelperClasses.PropertyCommand("Alignment", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("BackColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Font", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("ForeColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Format", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("HeaderText", true, true),
																										  new CustomControls.HelperClasses.PropertyCommand("MappingName", false, false),
																										  new CustomControls.HelperClasses.PropertyCommand("NullText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Visible", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Width", true, false)});
			columnStyle4.Visible = true;
			columnStyle4.Width = 160;
			columnStyle5.Alignment = System.Windows.Forms.HorizontalAlignment.Left;
			columnStyle5.BackColor = System.Drawing.Color.Transparent;
			columnStyle5.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										  new CustomControls.HelperClasses.CategoryCommand("Misc", true)});
			columnStyle5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			columnStyle5.ForeColor = System.Drawing.Color.Black;
			columnStyle5.Format = "";
			columnStyle5.HeaderText = "ShipAddress";
			columnStyle5.MappingName = "ShipAddress";
			columnStyle5.NullText = "Null";
			columnStyle5.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										  new CustomControls.HelperClasses.PropertyCommand("Alignment", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("BackColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Font", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("ForeColor", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Format", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("HeaderText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("MappingName", false, false),
																										  new CustomControls.HelperClasses.PropertyCommand("NullText", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Visible", true, false),
																										  new CustomControls.HelperClasses.PropertyCommand("Width", true, false)});
			columnStyle5.Visible = true;
			columnStyle5.Width = 160;
			tableStyle1.ColumnStyles.AddRange(new CustomControls.ApplicationBlocks.ColumnStyle[] {
																									 columnStyle1,
																									 columnStyle2,
																									 columnStyle3,
																									 columnStyle4,
																									 columnStyle5});
			tableStyle1.GridLineColor = System.Drawing.Color.Navy;
			tableStyle1.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										 new CustomControls.HelperClasses.PropertyCommand("AlternatingBackColor", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("BackColor", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("ColumnStyles", true, true),
																										 new CustomControls.HelperClasses.PropertyCommand("GridLineColor", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("HGridLine", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("RowHeight", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("VGridLine", true, false)});
			tableStyle1.Table = null;
			this.repBuilder.TableStyle = tableStyle1;
			// 
			// dg_Orders
			// 
			this.dg_Orders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dg_Orders.DataMember = "Orders";
			this.dg_Orders.DataSource = this.ds_Orders1;
			this.dg_Orders.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dg_Orders.Location = new System.Drawing.Point(10, 21);
			this.dg_Orders.Name = "dg_Orders";
			this.dg_Orders.Size = new System.Drawing.Size(504, 191);
			this.dg_Orders.TabIndex = 7;
			this.dg_Orders.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
																								  this.dataGridTableStyle1});
			// 
			// dataGridTableStyle1
			// 
			this.dataGridTableStyle1.DataGrid = this.dg_Orders;
			this.dataGridTableStyle1.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
																												  this.dataGridTextBoxColumn1,
																												  this.dataGridTextBoxColumn2,
																												  this.dataGridTextBoxColumn3,
																												  this.dataGridTextBoxColumn4,
																												  this.dataGridTextBoxColumn5,
																												  this.dataGridTextBoxColumn6,
																												  this.dataGridTextBoxColumn7,
																												  this.dataGridTextBoxColumn8});
			this.dataGridTableStyle1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridTableStyle1.MappingName = "Orders";
			// 
			// dataGridTextBoxColumn1
			// 
			this.dataGridTextBoxColumn1.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
			this.dataGridTextBoxColumn1.Format = "";
			this.dataGridTextBoxColumn1.FormatInfo = null;
			this.dataGridTextBoxColumn1.HeaderText = "Order ID";
			this.dataGridTextBoxColumn1.MappingName = "OrderID";
			this.dataGridTextBoxColumn1.Width = 75;
			// 
			// dataGridTextBoxColumn2
			// 
			this.dataGridTextBoxColumn2.Format = "";
			this.dataGridTextBoxColumn2.FormatInfo = null;
			this.dataGridTextBoxColumn2.HeaderText = "Customer ID";
			this.dataGridTextBoxColumn2.MappingName = "CustomerID";
			this.dataGridTextBoxColumn2.Width = 75;
			// 
			// dataGridTextBoxColumn3
			// 
			this.dataGridTextBoxColumn3.Format = "d";
			this.dataGridTextBoxColumn3.FormatInfo = null;
			this.dataGridTextBoxColumn3.HeaderText = "Order Date";
			this.dataGridTextBoxColumn3.MappingName = "OrderDate";
			this.dataGridTextBoxColumn3.Width = 120;
			// 
			// dataGridTextBoxColumn4
			// 
			this.dataGridTextBoxColumn4.Format = "D";
			this.dataGridTextBoxColumn4.FormatInfo = null;
			this.dataGridTextBoxColumn4.HeaderText = "Required Date";
			this.dataGridTextBoxColumn4.MappingName = "RequiredDate";
			this.dataGridTextBoxColumn4.Width = 120;
			// 
			// dataGridTextBoxColumn5
			// 
			this.dataGridTextBoxColumn5.Format = "";
			this.dataGridTextBoxColumn5.FormatInfo = null;
			this.dataGridTextBoxColumn5.HeaderText = "Ship Name";
			this.dataGridTextBoxColumn5.MappingName = "ShipName";
			this.dataGridTextBoxColumn5.Width = 75;
			// 
			// dataGridTextBoxColumn6
			// 
			this.dataGridTextBoxColumn6.Format = "";
			this.dataGridTextBoxColumn6.FormatInfo = null;
			this.dataGridTextBoxColumn6.HeaderText = "Ship Address";
			this.dataGridTextBoxColumn6.MappingName = "ShipAddress";
			this.dataGridTextBoxColumn6.Width = 120;
			// 
			// dataGridTextBoxColumn7
			// 
			this.dataGridTextBoxColumn7.Format = "";
			this.dataGridTextBoxColumn7.FormatInfo = null;
			this.dataGridTextBoxColumn7.HeaderText = "Ship City";
			this.dataGridTextBoxColumn7.MappingName = "ShipCity";
			this.dataGridTextBoxColumn7.Width = 75;
			// 
			// dataGridTextBoxColumn8
			// 
			this.dataGridTextBoxColumn8.Format = "";
			this.dataGridTextBoxColumn8.FormatInfo = null;
			this.dataGridTextBoxColumn8.HeaderText = "Ship Country";
			this.dataGridTextBoxColumn8.MappingName = "ShipCountry";
			this.dataGridTextBoxColumn8.Width = 75;
			// 
			// lb_ShipCity
			// 
			this.lb_ShipCity.DataSource = this.ds_Orders1.Orders;
			this.lb_ShipCity.DisplayMember = "ShipCity";
			this.lb_ShipCity.Location = new System.Drawing.Point(8, 52);
			this.lb_ShipCity.Name = "lb_ShipCity";
			this.lb_ShipCity.Size = new System.Drawing.Size(144, 108);
			this.lb_ShipCity.TabIndex = 9;
			this.lb_ShipCity.ValueMember = "ShipCity";
			// 
			// cb_OrderrID
			// 
			this.cb_OrderrID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.cb_OrderrID.DataSource = this.ds_Orders1.Orders;
			this.cb_OrderrID.DisplayMember = "OrderID";
			this.cb_OrderrID.Location = new System.Drawing.Point(521, 21);
			this.cb_OrderrID.Name = "cb_OrderrID";
			this.cb_OrderrID.Size = new System.Drawing.Size(142, 21);
			this.cb_OrderrID.TabIndex = 5;
			// 
			// tb_Main
			// 
			this.tb_Main.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.tb_Main.AutoSize = false;
			this.tb_Main.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.toolBarButton1,
																					   this.toolBarButton2,
																					   this.toolBarButton3,
																					   this.toolBarButton4,
																					   this.tbtn_Print});
			this.tb_Main.DropDownArrows = true;
			this.tb_Main.ImageList = this.img_Icons;
			this.tb_Main.Location = new System.Drawing.Point(0, 0);
			this.tb_Main.Name = "tb_Main";
			this.tb_Main.ShowToolTips = true;
			this.tb_Main.Size = new System.Drawing.Size(688, 28);
			this.tb_Main.TabIndex = 1;
			this.tb_Main.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right;
			this.tb_Main.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tb_Main_ButtonClick);
			// 
			// toolBarButton1
			// 
			this.toolBarButton1.ImageIndex = 0;
			// 
			// toolBarButton2
			// 
			this.toolBarButton2.ImageIndex = 1;
			// 
			// toolBarButton3
			// 
			this.toolBarButton3.ImageIndex = 2;
			// 
			// toolBarButton4
			// 
			this.toolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// tbtn_Print
			// 
			this.tbtn_Print.ImageIndex = 3;
			this.tbtn_Print.Text = "Print Assistant";
			// 
			// img_Icons
			// 
			this.img_Icons.ImageSize = new System.Drawing.Size(16, 16);
			this.img_Icons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("img_Icons.ImageStream")));
			this.img_Icons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// btn_PrintGrid
			// 
			this.btn_PrintGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_PrintGrid.Location = new System.Drawing.Point(521, 180);
			this.btn_PrintGrid.Name = "btn_PrintGrid";
			this.btn_PrintGrid.Size = new System.Drawing.Size(142, 32);
			this.btn_PrintGrid.TabIndex = 4;
			this.btn_PrintGrid.Text = "Print Grid";
			this.btn_PrintGrid.Click += new System.EventHandler(this.btn_PrintGrid_Click);
			// 
			// lb_CustomerID
			// 
			this.lb_CustomerID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_CustomerID.DataSource = this.ds_Orders1.Orders;
			this.lb_CustomerID.DisplayMember = "CustomerID";
			this.lb_CustomerID.Location = new System.Drawing.Point(521, 51);
			this.lb_CustomerID.Name = "lb_CustomerID";
			this.lb_CustomerID.Size = new System.Drawing.Size(142, 121);
			this.lb_CustomerID.TabIndex = 6;
			this.lb_CustomerID.ValueMember = "CustomerID";
			// 
			// gb_Custom
			// 
			this.gb_Custom.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gb_Custom.Controls.Add(this.dg_Orders);
			this.gb_Custom.Controls.Add(this.lb_CustomerID);
			this.gb_Custom.Controls.Add(this.cb_OrderrID);
			this.gb_Custom.Controls.Add(this.btn_PrintGrid);
			this.gb_Custom.Location = new System.Drawing.Point(8, 32);
			this.gb_Custom.Name = "gb_Custom";
			this.gb_Custom.Size = new System.Drawing.Size(672, 223);
			this.gb_Custom.TabIndex = 8;
			this.gb_Custom.TabStop = false;
			this.gb_Custom.Text = "Custom Controls";
			// 
			// gb_Standard
			// 
			this.gb_Standard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.gb_Standard.Controls.Add(this.cb_ShipName);
			this.gb_Standard.Controls.Add(this.lb_ShipCity);
			this.gb_Standard.Location = new System.Drawing.Point(8, 264);
			this.gb_Standard.Name = "gb_Standard";
			this.gb_Standard.Size = new System.Drawing.Size(160, 168);
			this.gb_Standard.TabIndex = 9;
			this.gb_Standard.TabStop = false;
			this.gb_Standard.Text = "Standard Controls";
			// 
			// cb_ShipName
			// 
			this.cb_ShipName.DataSource = this.ds_Orders1.Orders;
			this.cb_ShipName.DisplayMember = "ShipName";
			this.cb_ShipName.Location = new System.Drawing.Point(8, 20);
			this.cb_ShipName.Name = "cb_ShipName";
			this.cb_ShipName.Size = new System.Drawing.Size(144, 21);
			this.cb_ShipName.TabIndex = 8;
			this.cb_ShipName.ValueMember = "ShipName";
			// 
			// TestForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(688, 438);
			this.Controls.Add(this.gb_Standard);
			this.Controls.Add(this.gb_Custom);
			this.Controls.Add(this.tb_Main);
			this.Name = "TestForm";
			this.Text = "Test Form";
			this.Load += new System.EventHandler(this.TestForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds_Orders1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repBuilder)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dg_Orders)).EndInit();
			this.gb_Custom.ResumeLayout(false);
			this.gb_Standard.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new TestForm());
		}

		private void TestForm_Load(object sender, System.EventArgs e)
		{			
			ds_Orders1.ReadXml("Orders.xml",XmlReadMode.ReadSchema);
		
		}

		private void tb_Main_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			if(e.Button==tbtn_Print)
			{
				this.StartTracking();
			}
		}

		private void btn_PrintGrid_Click(object sender, System.EventArgs e)
		{
			ProjectLibrary.General.PrintSettingsDialog psd= new PrintSettingsDialog(this.repBuilder);
			psd.ShowDialog();
		}
	}
}
