using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.ComponentModel.Design.Serialization;
using System.Collections;
using CustomControls.Editors;
using CustomControls.ApplicationBlocks;
using CustomControls.HelperClasses;

namespace CustomControls.Functions
{
	public class General
	{
		public static bool IsInDesignMode()
		{
			// this is a radical way of finding out if you are in DesignMode
			//****************Windows Forms FAQ***************************
			//***********http://www.syncfusion.com/FAQ/Winforms/**********

			string exePath = Application.ExecutablePath;  
			exePath = exePath.ToLower(); 
 
			if(Application.ExecutablePath.ToLower().IndexOf("devenv.exe") > -1) 
			{ 
				return true;
			}     
			else
			{
				return false;
			}

		}

		public static StringAlignment HorAlignToStrAlign(HorizontalAlignment alignment)
		{
			switch (alignment)
			{
				case HorizontalAlignment.Center:
				{
					return StringAlignment.Center;
				}
				case HorizontalAlignment.Left:
				{
					return StringAlignment.Near;
				}
				case HorizontalAlignment.Right:
				{
					return StringAlignment.Far;
				}
				default:
				{
					return StringAlignment.Near;
				}
			}
		}

	}
}
