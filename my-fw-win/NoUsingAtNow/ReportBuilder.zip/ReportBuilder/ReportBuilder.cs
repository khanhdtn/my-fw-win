using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CustomControls.Editors;
using CustomControls.BaseClasses;
using CustomControls.HelperClasses;
using System.Drawing.Design;
using System.Collections;
using System.ComponentModel.Design;

namespace CustomControls.ApplicationBlocks
{

	public class ReportBuilder:Component,ISupportInitialize, IDataSourcesProvider
	{
		private DataView dataView=null;
		private object _DataSource;
		private PrintEngine printEngine= new PrintEngine();
		private PaintEngine paintEngine= new PaintEngine();
	
		[Category ("Data")]
		[Editor(typeof(ReportDataSourceEditor), typeof(UITypeEditor))]
		public object DataSource
		{
			get{return  _DataSource;}
			set
			{
				_DataSource=value;
					dataView= GetDataView(DataSource);
					if(dataView!=null)
					{
						if(TableStyle.Table!=null&& TableStyle.Table.TableName!=dataView.Table.TableName){TableStyle.ColumnStyles.Clear();}
						TableStyle.Table=(dataView!=null?dataView.Table:null);
						paintEngine.DataSource=dataView;
					}
				
			}
		}

		
		[Category ("Headers & Footers")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		[Editor(typeof(PrintElementCollEdit),typeof(System.Drawing.Design.UITypeEditor))]
		public PrintElement ReportHeader
		{
			get{return printEngine.ReportHeader;}
		}

		
		[Category ("Headers & Footers")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		[Editor(typeof(PrintElementCollEdit),typeof(System.Drawing.Design.UITypeEditor))]
		public PrintElement ReportFooter
		{
			get{return printEngine.ReportFooter;}
		}

		
		[Category ("Headers & Footers")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		[Editor(typeof(PrintElementCollEdit),typeof(System.Drawing.Design.UITypeEditor))]
		public PrintElement PageHeader
		{
			get{return printEngine.PageHeader;}
		}

		
		[Category ("Headers & Footers")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		[Editor(typeof(PrintElementCollEdit),typeof(System.Drawing.Design.UITypeEditor))]
		public PrintElement PageFooter
		{
			get{return printEngine.PageFooter;}
		}

		
		[Category("Report Body")]
		[Editor(typeof(TableStyleTypeEditor),typeof(System.Drawing.Design.UITypeEditor))]
		
		public TableStyle TableStyle
		{
			get{return paintEngine.TableStyle;}
			set
			{
				paintEngine.TableStyle= value;
				paintEngine.TableStyle.Table=(dataView!=null?dataView.Table:null);
			}
	
		}

		[Browsable(false)]
		public SNode[] DataSources
		{
			get{ return GetDataSources();}
		}
	
		public ReportBuilder()
		{
			paintEngine.DataSource=dataView;
			printEngine.Client=paintEngine;
			TableStyle.Table=(dataView!=null?(dataView).Table:null);
			
		}
		public void BeginInit()
		{
	
		}

		public void EndInit()
		{		
		
			if (dataView==null)
				{
					dataView= GetDataView(DataSource);
					if(dataView!=null)
					{
						TableStyle.Table=(dataView!=null?dataView.Table:null);
						paintEngine.DataSource=dataView;
					}
				}
			
			TableStyle.EndInit();
			
			// if you  uncomment the following section and modify PrintCommand class by deleteing the code that overrides the PropertyCommands and CategoryCommands properties
			//will enable  the propertys control for headers and footers
			/*
			foreach (PrintCommand pc in ReportHeader)
			{
				pc.EndInit();
			}
			
			foreach (PrintCommand pc in ReportFooter)
			{
				pc.EndInit();
			}
			
			foreach (PrintCommand pc in PageHeader)
			{
				pc.EndInit();
			}
			
			foreach (PrintCommand pc in PageFooter)
			{
				pc.EndInit();
			}
			*/
		}

		public void  ShowPrintPreviewDialog()
		{
			PrintPreviewDialog ppd= new PrintPreviewDialog();
			ppd.Document=printEngine;
			ppd.ShowDialog();
		}

		public void  ShowPageSetupDialog()
		{
			PageSetupDialog psd= new PageSetupDialog();
			psd.Document=printEngine;
			psd.ShowDialog();
		}

		public void  ShowPrintDialog()
		{
			PrintDialog psd= new PrintDialog();
			psd.Document=printEngine;
			psd.AllowSomePages=true;
			psd.ShowDialog();
		}
		
		public void ShowTableStyleDialog()
		{
			TableStyleEditor tse= new TableStyleEditor(this.TableStyle);
			tse.ShowDialog();
		}

		public void ShowReportHeaderDialog()
		{
			CustomControls.HelperClasses.PrintElementCollEditForm pecef= new CustomControls.HelperClasses.PrintElementCollEditForm();
            pecef.Collection=this.ReportHeader;
			pecef.Show();
		}

		public void ShowReportFooterDialog()
		{
			CustomControls.HelperClasses.PrintElementCollEditForm pecef= new CustomControls.HelperClasses.PrintElementCollEditForm();
			pecef.Collection=this.ReportFooter ;
			pecef.Show();
		}
		public void ShowPageHeaderDialog()
		{
			CustomControls.HelperClasses.PrintElementCollEditForm pecef= new CustomControls.HelperClasses.PrintElementCollEditForm();
			pecef.Collection=this.PageHeader;
			pecef.Show();
		}
		public void ShowPageFooterDialog()
		{
			CustomControls.HelperClasses.PrintElementCollEditForm pecef= new CustomControls.HelperClasses.PrintElementCollEditForm();
			pecef.Collection=this.PageFooter;
			pecef.Show();
		}

		public void Print()
		{
			this.printEngine.Print();
		}

		public DataView GetDataView(object dataSource)
		{
			DataView dv=null;
			if (dataSource is IReportSource)
			{
				dv=((IReportSource)dataSource).GetSource();
			}
			else if (dataSource is DataView)
			{
				dv=(DataView)dataSource;
			}
			else if(dataSource is DataTable)
			{
				dv=((DataTable)dataSource).DefaultView;
			}
			else if(dataSource is ComboBox)
			{
				ComboBox cb=(ComboBox)dataSource;
				if(cb.DataSource!=null && cb.BindingContext!=null)
				{				
					CurrencyManager cm = (CurrencyManager)cb.BindingContext[cb.DataSource];
					if(cm!=null && cm.List !=null && cm.List is DataView)
					{
						dv=(DataView)cm.List;
							
					}
				}
			}
			else if(dataSource is ListBox)
			{
				ListBox lb=(ListBox)dataSource;
				if(lb.DataSource!=null && lb.BindingContext!=null)
				{
					CurrencyManager cm = (CurrencyManager)lb.BindingContext[lb.DataSource];
					if(cm!=null && cm.List !=null && cm.List is DataView)
					{
						dv=(DataView)cm.List;
					}
							
				}
			}
			else if(dataSource is DataGrid)
			{
				DataGrid dg=(DataGrid)dataSource;
				if(dg.DataSource!=null && dg.BindingContext!=null)
				{
					CurrencyManager cm = (CurrencyManager)dg.BindingContext[dg.DataSource];
					if(cm!=null && cm.List !=null && cm.List is DataView)
					{
						dv=(DataView)cm.List;
					}
				}

			}
			return dv;
		}

	
		private ArrayList AddSources(ArrayList nodes, System.Windows.Forms.Control.ControlCollection ctrls)
		{
			
			foreach (Control c in ctrls)
			{
				
				
					if(c is IReportSource)
					{
						if(((IReportSource)(c)).GetSource()!=null)
						{
							nodes.Add(new SNode(c.Name,c));
						}
					}
					else if(c is ComboBox)
					{
						ComboBox cb=(ComboBox)c;
						if(cb.DataSource!=null && cb.BindingContext!=null)
						{				
							CurrencyManager cm = (CurrencyManager)cb.BindingContext[cb.DataSource];
							if(cm!=null && cm.List !=null && cm.List is DataView)
							{
								nodes.Add(new SNode(cb.Name,cb));
							
							}
						}
					}
					else if(c is ListBox)
					{
						ListBox lb=(ListBox)c;
						if(lb.DataSource!=null && lb.BindingContext!=null)
						{
							CurrencyManager cm = (CurrencyManager)lb.BindingContext[lb.DataSource];
							if(cm!=null && cm.List !=null && cm.List is DataView)
							{
								nodes.Add(new SNode(lb.Name,lb));
							}
							
						}
					}
					else if(c is DataGrid)
					{
						DataGrid dg=(DataGrid)c;
						if(dg.DataSource!=null && dg.BindingContext!=null)
						{
							CurrencyManager cm = (CurrencyManager)dg.BindingContext[dg.DataSource];
							if(cm!=null && cm.List !=null && cm.List is DataView)
							{
								nodes.Add(new SNode(dg.Name,dg));
							}
						}

					}
				else if(c.Controls.Count>0)
				{
					AddSources(nodes ,c.Controls);
				}
				
			}

			
			return nodes;
		}

		private SNode[] GetDataSources()
		{
			ArrayList nodes=new ArrayList();
			if (this.DesignMode)
			{
				foreach(IComponent c in this.Container.Components )
				{
					if (c is DataView)
					{
						nodes.Add(new SNode(((DataView)c).Table.TableName, (DataView)c));
						}
					else if( c is DataSet)
					{
						SNode dsNode=new SNode(((DataSet)c).DataSetName,null);
						foreach(DataTable table in ((DataSet)c).Tables)
						{
							dsNode.Nodes.Add(new SNode(table.TableName,table));
						}
						nodes.Add(dsNode);
					}

				}

			
				IReferenceService rs = (IReferenceService)this.GetService(typeof(IReferenceService));
				if( rs != null )
				{			
					Form parentForm= (Form)rs.GetReferences(typeof(Form))[0];
					if(parentForm!=null)
					{
						AddSources(nodes,parentForm.Controls);
					}
				}

				SNode[] dataSources= new SNode[nodes.Count];

				dataSources=(SNode[])nodes.ToArray(typeof(SNode));
			
				return dataSources;
			}
			return null;
		}
	}
}
