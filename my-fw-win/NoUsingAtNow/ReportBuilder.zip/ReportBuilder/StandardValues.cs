using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Drawing.Design;
using System.Windows.Forms.Design;

namespace CustomControls.Editors
{
	
	public class StandardValuesConverter:StringConverter
	{
		public StandardValuesConverter()
		{
		}

		

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context) 
		{
			return true;
		}

		public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) 
		{
			      
			if(context!=null && context.Instance!=null && context.Instance is ISupportStandardValues)
			{
				return ((ISupportStandardValues)context.Instance).StandardValuesExclusive;
			}
			return true;
		}

		public override StandardValuesCollection GetStandardValues(	ITypeDescriptorContext context) 
		{
			if(context!=null && context.Instance!=null && context.Instance is ISupportStandardValues)
			{
				return new StandardValuesCollection(((ISupportStandardValues)context.Instance).GetStandardValues());
			}
			return null;
			
			
		}
	}

	public interface ISupportStandardValues
	{
		string[] GetStandardValues();
		bool StandardValuesExclusive{get;}
	}
}
