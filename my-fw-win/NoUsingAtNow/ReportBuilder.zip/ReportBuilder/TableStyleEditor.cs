using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CustomControls.ApplicationBlocks;

namespace CustomControls.Editors
{
	/// <summary>
	/// Summary description for TableStyleEditor.
	/// </summary>
	public class TableStyleEditor : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel pan_Buttons;
		private System.Windows.Forms.Panel pan_Display;
		private System.Windows.Forms.PropertyGrid pg;
		private CustomControls.Win32Controls.PushButton btn_OK;
		private CustomControls.Win32Controls.DropDownListBoxButton btn_Format;
		private CustomControls.ApplicationBlocks.TableStyle tableStyle;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TableStyleEditor(TableStyle tableStyle)
		{
			
			InitializeComponent();
			this.tableStyle=tableStyle;
			pg.SelectedObject=tableStyle;
			LocalizeForm();
			btn_Format.ItemSelected+=new CustomControls.Win32Controls.DropDownListBoxButton.ItemSelectedEventHandler (Format_SelectedIndexChanged);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pan_Buttons = new System.Windows.Forms.Panel();
			this.btn_Format = new CustomControls.Win32Controls.DropDownListBoxButton();
			this.btn_OK = new CustomControls.Win32Controls.PushButton();
			this.pan_Display = new System.Windows.Forms.Panel();
			this.pg = new System.Windows.Forms.PropertyGrid();
			this.pan_Buttons.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.btn_Format)).BeginInit();
			this.pan_Display.SuspendLayout();
			this.SuspendLayout();
			// 
			// pan_Buttons
			// 
			this.pan_Buttons.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pan_Buttons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pan_Buttons.Controls.Add(this.btn_Format);
			this.pan_Buttons.Controls.Add(this.btn_OK);
			this.pan_Buttons.Location = new System.Drawing.Point(6, 417);
			this.pan_Buttons.Name = "pan_Buttons";
			this.pan_Buttons.Size = new System.Drawing.Size(420, 40);
			this.pan_Buttons.TabIndex = 0;
			// 
			// btn_Format
			// 
			this.btn_Format.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.btn_Format.Location = new System.Drawing.Point(330, 7);
			this.btn_Format.Name = "btn_Format";
			this.btn_Format.Size = new System.Drawing.Size(80, 24);
			this.btn_Format.TabIndex = 0;
			this.btn_Format.Text = "Format";
			this.btn_Format.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btn_OK
			// 
			this.btn_OK.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btn_OK.Location = new System.Drawing.Point(8, 8);
			this.btn_OK.Name = "btn_OK";
			this.btn_OK.Size = new System.Drawing.Size(80, 24);
			this.btn_OK.TabIndex = 0;
			this.btn_OK.Text = "OK";
			// 
			// pan_Display
			// 
			this.pan_Display.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pan_Display.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pan_Display.Controls.Add(this.pg);
			this.pan_Display.Location = new System.Drawing.Point(6, 8);
			this.pan_Display.Name = "pan_Display";
			this.pan_Display.Size = new System.Drawing.Size(420, 400);
			this.pan_Display.TabIndex = 1;
			// 
			// pg
			// 
			this.pg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pg.CommandsVisibleIfAvailable = true;
			this.pg.LargeButtons = false;
			this.pg.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.pg.Location = new System.Drawing.Point(7, 7);
			this.pg.Name = "pg";
			this.pg.Size = new System.Drawing.Size(404, 384);
			this.pg.TabIndex = 0;
			this.pg.Text = "PropertyGrid";
			this.pg.ViewBackColor = System.Drawing.SystemColors.Window;
			this.pg.ViewForeColor = System.Drawing.SystemColors.WindowText;
			// 
			// TableStyleEditor
			// 
			this.AcceptButton = this.btn_OK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 464);
			this.ControlBox = false;
			this.Controls.Add(this.pan_Display);
			this.Controls.Add(this.pan_Buttons);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MinimumSize = new System.Drawing.Size(440, 440);
			this.Name = "TableStyleEditor";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "TableStyleEditor";
			this.TopMost = true;
			this.pan_Buttons.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.btn_Format)).EndInit();
			this.pan_Display.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region "Implementation"

		private void Format_SelectedIndexChanged(object sender, CustomControls.HelperClasses.ItemSelectedEventArgs e)
		{
			int selIndex=e.SelectedIndex;

			if(selIndex>-1)
			{
				if(selIndex==0)
				{
					SetFormat_MaxSav();
				}
				else 
				{
					SetFormat_Normal();
				}
				
			}
		}

		private void SetFormat_MaxSav()
		{
			tableStyle.BackColor=Color.White;
			tableStyle.AlternatingBackColor=Color.White;
			tableStyle.GridLineColor=Color.Black;
			tableStyle.HGridLine=true;
			tableStyle.VGridLine=true;
						

			foreach( CustomControls.ApplicationBlocks.ColumnStyle cs in tableStyle.ColumnStyles)
			{
				CustomControls.HelperClasses.PropertyCommand pc=cs.PropertyCommands["BackColor"];
	
				if( pc==null || !pc.ReadOnly)
				{
					cs.BackColor=Color.Transparent;
					cs.ForeColor=Color.Black;
				}
			}

			pg.Refresh();
		}

		private void SetFormat_Normal()
		{
			tableStyle.BackColor=Color.White;
			tableStyle.AlternatingBackColor=Color.Gainsboro;
			tableStyle.GridLineColor=Color.Black;
			tableStyle.HGridLine=true;
			tableStyle.VGridLine=true;
			
				

			foreach( CustomControls.ApplicationBlocks.ColumnStyle cs in tableStyle.ColumnStyles)
			{
				CustomControls.HelperClasses.PropertyCommand pc=cs.PropertyCommands["BackColor"];
	
				if( pc==null ||! pc.ReadOnly)
				{
					cs.BackColor=Color.Transparent;
					cs.ForeColor=Color.Black;
				}
			}

			pg.Refresh();
		}


		private void LocalizeForm()
		{
			this.btn_Format.Text=CustomControls.Globalization.Dictionary.GetLocalizedText(btn_Format.Text);
			this.btn_OK.Text=CustomControls.Globalization.Dictionary.GetLocalizedText(btn_OK.Text);
			btn_Format.List.Items.Add(CustomControls.Globalization.Dictionary.GetLocalizedText("Maximum Savings"));
			btn_Format.List.Items.Add(CustomControls.Globalization.Dictionary.GetLocalizedText("Normal"));
		}

		#endregion
	}
}
