using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.ComponentModel.Design.Serialization;
using CustomControls.ApplicationBlocks;
using CustomControls.HelperClasses;

namespace CustomControls.ApplicationBlocks
{
	[TypeConverter(typeof(TableStyle_Converter))]
	public class TableStyle:DynamicTypeDescriptor
	{
		#region "Variables"

		public event EventHandler StyleChanged;
	
		private ColumnStyles _ColumnStyles;
		private DataTable _Table=null;
		private int _RowHeight=20;
		private bool _HGridLine=true;
		private bool _VGridLine= true;
		private Color _BackColor=Color.White;
		private Color _AlternatingBackColor=Color.WhiteSmoke;
		private Color _GridLineColor=Color.Navy;
			
		

		#endregion

		#region "Properties"


		[Browsable(false)]
//		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public DataTable Table
		{
			get{return _Table;}
			set	
			{
				_Table= value;	
			}
		}

		
	
	


	

		[Category("Grid")]
		[DefaultValue(typeof(bool),"True")]	
		public bool VGridLine
		{
			get{return _VGridLine;}
			set
			{
				if(value!=_VGridLine)
				{
					_VGridLine= value;
					OnStyleChanged(new EventArgs());
				}
			}
		}


		[Category("Grid")]
		[DefaultValue(typeof(bool),"True")]	
		public bool HGridLine
		{
			get{return _HGridLine;}
			set
			{
				if(value!=_HGridLine)
				{
					_HGridLine= value;
					OnStyleChanged(new EventArgs());
				}
			}
		}

		

		

		[Category("Grid")]
		[DefaultValue(typeof(int),"20")]
		public int RowHeight
		{
			get{return _RowHeight;}
			set
			{
				if(value!=_RowHeight)
				{
					_RowHeight= value;
					OnStyleChanged(new EventArgs());
				}
			}
		}

		[Category ("Column Styles")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		[Editor(typeof(ColumnStyleCollEdit),typeof(System.Drawing.Design.UITypeEditor))]
		public ColumnStyles ColumnStyles
		{
			get{return _ColumnStyles;}
		}


	
		

		

		[Category("Grid")]
		public Color BackColor
		{
			get{return _BackColor;}
			set
			{
				if(value!=_BackColor)
				{
					_BackColor=value;
					OnStyleChanged(new EventArgs());
				}
			}
		}

		

		[Category("Grid")]
		public Color AlternatingBackColor
		{
			get{return _AlternatingBackColor;}
			set
			{
				if(value!=_AlternatingBackColor)
				{
					_AlternatingBackColor=value;
					OnStyleChanged(new EventArgs());
				}
			}
		}

		

		[Category("Grid")]
		public Color GridLineColor
		{
			get{return _GridLineColor;}
			set
			{
				if(value!=_GridLineColor)
				{
					_GridLineColor=value;
					OnStyleChanged(new EventArgs());
				}
			}
		}



				
		

		#endregion

		#region "Constructor"

		public TableStyle():base()
		{
			_ColumnStyles= new ColumnStyles(this);
		}
	

		#endregion
	
		#region "Localization"

		public override string GetLocalizedName(string Name)
		{			
			string name=CustomControls.Globalization.Dictionary.Translate(Name);
			if(name!=null ){return name;}
			return base.GetLocalizedName (Name);
		}

		public override string GetLocalizedDescription(string Description)
		{
			string descr=CustomControls.Globalization.Dictionary.Translate(Description + "_Descr");
			if(descr!=null ){return descr;}
			return base.GetLocalizedName (Description);
		}

        
		#endregion
	
		#region "Implementation"

		public override void EndInit()
		{					
			base.EndInit ();
			foreach(ColumnStyle col in this.ColumnStyles )
			{
				col.EndInit();
			}
		}

		protected virtual void OnStyleChanged(EventArgs e)
		{
			if(StyleChanged!=null)
			{
				StyleChanged(this,e);
			}
		}
		
		#endregion

	}


	
}


namespace CustomControls.HelperClasses
{
	internal class TableStyle_Converter:ExpandableObjectConverter
	{
	
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(TableStyle).GetConstructor(new Type[0]), null,false);
			}
			return base.ConvertTo(context,info,value,destType);
		}

		
	}
}